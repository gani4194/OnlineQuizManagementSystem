package com.quiz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineQuizManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineQuizManagementSystemApplication.class, args);
	}
}
