package com.quiz.exception;

public class AdminIdNotFoundException extends Exception {
	
	public AdminIdNotFoundException (String message) {
		super(message);
	}
       
}
