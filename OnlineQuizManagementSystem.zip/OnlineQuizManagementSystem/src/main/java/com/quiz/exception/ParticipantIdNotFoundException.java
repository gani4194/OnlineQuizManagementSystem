package com.quiz.exception;

public class ParticipantIdNotFoundException extends Exception {


	public ParticipantIdNotFoundException (String message) {
		super(message);
	}
}
