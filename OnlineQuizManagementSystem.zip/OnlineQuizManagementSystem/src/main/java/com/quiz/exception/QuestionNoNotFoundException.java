package com.quiz.exception;

public class QuestionNoNotFoundException extends Exception{
	
	public QuestionNoNotFoundException(String message) {
		super(message);
	}
}
	






//	public QuestionNoNotFoundException (String message) {
//	super();
//	this.message = message;
//	}
//	
//	public QuestionNoNotFoundException() {
//                            System.out.println("Sorry! Question No Not Available..!");
//	}
//}