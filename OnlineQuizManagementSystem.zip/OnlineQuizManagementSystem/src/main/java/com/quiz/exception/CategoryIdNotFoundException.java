package com.quiz.exception;

public class CategoryIdNotFoundException extends Exception {
	
	public CategoryIdNotFoundException (String message) {
		super(message);
	}
       
}
