package com.quiz.exception;

public class QuizIdNotFoundException extends Exception{
	
	public QuizIdNotFoundException(String message) {
		super(message);
	}
}
